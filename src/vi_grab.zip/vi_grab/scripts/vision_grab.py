# #!/home/airlab1/miniconda3/envs/ros1/bin/python3
# # -*- coding=UTF-8 -*-
# from std_msgs.msg import String, Bool, Empty
# import rospy, sys
# import moveit_commander
# # from rm_msgs.msg import MoveJ_P, Arm_Current_State, Gripper_Set, Gripper_Pick, ArmState, MoveL, MoveJ
# from geometry_msgs.msg import Pose, PoseStamped
# import numpy as np
# from scipy.spatial.transform import Rotation as R
# # from vi_grab.msg import ObjectInfo
# from vi_msgs.msg import ObjectInfo
# from geometry_msgs.msg import TransformStamped, PointStamped
# from geometry_msgs.msg import Point, Quaternion

# # 相机坐标系到机械臂末端坐标系的旋转矩阵，通过手眼标定得到
# rotation_matrix = np.array([[0.96827159 ,-0.24892518 , 0.02205399],
#                             [-0.0187048 ,  0.01581218 , 0.99970001],
#                             [-0.24919922 ,-0.96839363 , 0.01065439]])
# # 相机坐标系到机械臂末端坐标系的平移向量，通过手眼标定得到
# translation_vector = np.array([-0.01827614, -0.05328887, 0.08421597])

# # 全局变量：MoveIt arm对象
# arm = None

# # 相机坐标系物体到机械臂基坐标系转换函数
# def convert(x, y, z, x1, y1, z1, rx, ry, rz):
#     """
#     函数功能：我们需要将旋转向量和平移向量转换为齐次变换矩阵，然后使用深度相机识别到的物体坐标（x, y, z）和
#     机械臂末端的位姿（x1,y1,z1,rx,ry,rz）来计算物体相对于机械臂基座的位姿（x, y, z, rx, ry, rz）
#     输入参数：深度相机识别到的物体坐标（x, y, z）和机械臂末端的位姿（x1,y1,z1,rx,ry,rz）
#     返回值：物体在机械臂基座坐标系下的位置（x, y, z）
#     """
#     global rotation_matrix, translation_vector
#     obj_camera_coordinates = np.array([x, y, z])

#     # 机械臂末端的位姿，单位为弧度
#     end_effector_pose = np.array([x1, y1, z1, rx, ry, rz])
    
#     # 将旋转矩阵和平移向量转换为齐次变换矩阵
#     T_camera_to_end_effector = np.eye(4)
#     T_camera_to_end_effector[:3, :3] = rotation_matrix
#     T_camera_to_end_effector[:3, 3] = translation_vector
    
#     # 机械臂末端的位姿转换为齐次变换矩阵
#     position = end_effector_pose[:3]
#     orientation = R.from_euler('xyz', end_effector_pose[3:], degrees=False).as_matrix()
#     T_base_to_end_effector = np.eye(4)
#     T_base_to_end_effector[:3, :3] = orientation
#     T_base_to_end_effector[:3, 3] = position
    
#     # 计算物体相对于机械臂基座的位姿
#     obj_camera_coordinates_homo = np.append(obj_camera_coordinates, [1])  # 将物体坐标转换为齐次坐标
#     obj_end_effector_coordinates_homo = T_camera_to_end_effector.dot(obj_camera_coordinates_homo)
#     obj_base_coordinates_homo = T_base_to_end_effector.dot(obj_end_effector_coordinates_homo)
#     obj_base_coordinates = obj_base_coordinates_homo[:3]  # 从齐次坐标中提取物体的x, y, z坐标
    
#     # 计算物体的旋转
#     obj_orientation_matrix = T_base_to_end_effector[:3, :3].dot(rotation_matrix)
#     obj_orientation_euler = R.from_matrix(obj_orientation_matrix).as_euler('xyz', degrees=False)
    
#     # 组合结果
#     obj_base_pose = np.hstack((obj_base_coordinates, obj_orientation_euler))
#     obj_base_pose[3:] = rx, ry, rz
#     return obj_base_pose


# # 接收到识别物体的回调函数
# def object_pose_callback(data):
#     """
#     函数功能：每帧图像经过识别后的回调函数，若有抓取指令，则判断当前画面帧中是否有被抓物体，如果有则将物体坐标进行转换，并让机械臂执行抓取动作
#     输入参数：无
#     返回值：无
#     """
#     global object_msg, arm
    
#     # 判断当前帧的识别结果是否有要抓取的物体
#     if data.object_class == object_msg.data and len(object_msg.data) > 0:
#         # 使用MoveIt获取当前机械臂末端位姿
#         current_pose = arm.get_current_pose().pose
#         print("Current end effector pose:")
#         print(current_pose)
#         rospy.sleep(1)
        
#         # 使用MoveIt获取当前关节角度
#         current_joints = arm.get_current_joint_values()
#         print("Current joint values:")
#         print(current_joints)
        
#         # 将四元数转换为欧拉角（用于convert函数）
#         quat = [current_pose.orientation.x, current_pose.orientation.y, 
#                 current_pose.orientation.z, current_pose.orientation.w]
#         euler = R.from_quat(quat).as_euler('xyz', degrees=False)
        
#         # 计算机械臂基坐标系下的物体坐标
#         result = convert(data.x, data.y, data.z, 
#                         current_pose.position.x, current_pose.position.y, current_pose.position.z,
#                         euler[0], euler[1], euler[2])
#         print(data.object_class, ':', result)
        
#         # 抓取物体（传递当前位姿和关节角度）
#         catch(result, current_pose, current_joints)
        
#         # 清除object_msg的信息，之后二次发布抓取物体信息可以再执行
#         object_msg.data = ''


# def movej_type(joint_positions, speed=0.5):
#     '''
#     函数功能：通过输入机械臂每个关节的数值（弧度），让机械臂运动到指定姿态
#     输入参数：joint_positions [joint1,joint2,joint3,joint4,joint5,joint6]、speed (0-1)
#     返回值：无
#     '''
#     global arm
    
#     # 设置机械臂运动的允许误差值
#     arm.set_goal_joint_tolerance(0.001)
    
#     # 设置允许的最大速度和加速度
#     arm.set_max_acceleration_scaling_factor(speed)
#     arm.set_max_velocity_scaling_factor(speed)
    
#     # 设置机械臂的目标位置
#     arm.set_joint_value_target(joint_positions)
    
#     # 控制机械臂完成运动
#     arm.go()
#     rospy.sleep(0.5)


# def movejp_type(pose, speed=0.5):
#     '''
#     函数功能：通过输入机械臂末端的位姿数值，让机械臂运动到指定位姿（关节空间规划）
#     输入参数：pose（position.x、position.y、position.z、orientation.x、orientation.y、orientation.z、orientation.w）、speed
#     返回值：无
#     '''
#     global arm
    
#     # 获取终端link的名称
#     end_effector_link = arm.get_end_effector_link()
    
#     # 设置目标位置所使用的参考坐标系
#     reference_frame = 'base_link'
#     arm.set_pose_reference_frame(reference_frame)
    
#     # 当运动规划失败后，允许重新规划
#     arm.allow_replanning(True)
    
#     # 设置位置和姿态的允许误差
#     arm.set_goal_position_tolerance(0.001)
#     arm.set_goal_orientation_tolerance(0.01)
    
#     # 设置允许的最大速度和加速度
#     arm.set_max_acceleration_scaling_factor(speed)
#     arm.set_max_velocity_scaling_factor(speed)
    
#     # 设置机械臂工作空间中的目标位姿
#     target_pose = PoseStamped()
#     target_pose.header.frame_id = reference_frame
#     target_pose.header.stamp = rospy.Time.now()
#     target_pose.pose.position.x = pose[0]
#     target_pose.pose.position.y = pose[1]
#     target_pose.pose.position.z = pose[2]
#     target_pose.pose.orientation.x = pose[3]
#     target_pose.pose.orientation.y = pose[4]
#     target_pose.pose.orientation.z = pose[5]
#     target_pose.pose.orientation.w = pose[6]
    
#     # 设置机器臂当前的状态作为运动初始状态
#     arm.set_start_state_to_current_state()
    
#     # 设置机械臂终端运动的目标位姿
#     arm.set_pose_target(target_pose, end_effector_link)
    
#     # 规划并执行运动路径
#     arm.go()
#     rospy.sleep(0.5)


# def movel_type(pose, speed=0.5):
#     '''
#     函数功能：通过输入机械臂末端的位姿数值，让机械臂直线运动到指定位姿（笛卡尔空间规划）
#     输入参数：pose（position.x、position.y、position.z、orientation.x、orientation.y、orientation.z、orientation.w）、speed
#     返回值：无
#     '''
#     global arm
    
#     # 获取终端link的名称
#     end_effector_link = arm.get_end_effector_link()
    
#     # 设置目标位置所使用的参考坐标系
#     reference_frame = 'base_link'
#     arm.set_pose_reference_frame(reference_frame)
    
#     # 当运动规划失败后，允许重新规划
#     arm.allow_replanning(True)
    
#     # 设置位置和姿态的允许误差
#     arm.set_goal_position_tolerance(0.001)
#     arm.set_goal_orientation_tolerance(0.01)
    
#     # 设置允许的最大速度和加速度
#     arm.set_max_acceleration_scaling_factor(speed)
#     arm.set_max_velocity_scaling_factor(speed)
    
#     # 设置机械臂工作空间中的目标位姿
#     target_pose = PoseStamped()
#     target_pose.header.frame_id = reference_frame
#     target_pose.header.stamp = rospy.Time.now()
#     target_pose.pose.position.x = pose[0]
#     target_pose.pose.position.y = pose[1]
#     target_pose.pose.position.z = pose[2]
#     target_pose.pose.orientation.x = pose[3]
#     target_pose.pose.orientation.y = pose[4]
#     target_pose.pose.orientation.z = pose[5]
#     target_pose.pose.orientation.w = pose[6]
    
#     # 设置机器臂当前的状态作为运动初始状态
#     arm.set_start_state_to_current_state()
    
#     # 设置机械臂终端运动的目标位姿
#     arm.set_pose_target(target_pose, end_effector_link)
    
#     # 规划运动路径
#     traj = arm.plan()
    
#     # 按照规划的运动路径控制机械臂运动
#     arm.execute(traj)
#     rospy.sleep(0.5)


# def arm_ready_pose():
#     '''
#     函数功能：执行整个抓取流程前先运动到一个能够稳定获取物体坐标信息的姿态
#     输入参数：无
#     返回值：无
#     '''
#     global arm
    
#     # 设置机械臂运动的允许误差值
#     arm.set_goal_joint_tolerance(0.001)
    
#     # 设置允许的最大速度和加速度
#     arm.set_max_acceleration_scaling_factor(0.3)
#     arm.set_max_velocity_scaling_factor(0.3)
    
#     # 设置拍照姿态的关节角度
#     pic_joint = [-1.36,-1.26,0.87,0.09,-0.95,0.34]
#     arm.set_joint_value_target(pic_joint)
    
#     # 控制机械臂完成运动
#     arm.go()
#     rospy.sleep(0.5)


# def catch(result, current_pose, current_joints):
#     '''
#     函数功能：机械臂执行抓取动作
#     输入参数：经过convert函数转换得到的'result'、当前末端位姿'current_pose'和当前关节角度'current_joints'
#     返回值：无
#     '''
#     # 流程第一步：运动到物体附近（偏移7cm）
#     movejp_type([result[0] + 0.07, result[1], result[2], 
#                  current_pose.orientation.x, current_pose.orientation.y,
#                  current_pose.orientation.z, current_pose.orientation.w], 0.3)
#     print('*************************catching  step1*************************')

#     # 抓取第二步：直线运动到物体坐标处
#     movel_type([result[0], result[1], result[2], 
#                 current_pose.orientation.x, current_pose.orientation.y,
#                 current_pose.orientation.z, current_pose.orientation.w], 0.3)
#     print('*************************catching  step2*************************')

#     # 抓取第三步：闭合夹爪
#     gripper_close()
#     print('*************************catching  step3*************************')

#     # 倒水第一步：抬起物体5厘米
#     movel_type([result[0], result[1], result[2] + 0.05, 
#                 current_pose.orientation.x, current_pose.orientation.y,
#                 current_pose.orientation.z, current_pose.orientation.w], 0.3)
#     print('*************************pour  step1*************************')

#     # 倒水第二步：旋转机械臂末端关节
#     movej_type([current_joints[0], current_joints[1], current_joints[2], 
#                 current_joints[3], current_joints[4], current_joints[5] + 1], 0.3)
#     print('*************************pour  step2*************************')


# def gripper_open():
#     '''
#     函数功能：打开夹爪（通过设置关节6的角度为0）
#     输入参数：无
#     返回值：无
#     '''
#     global arm
    
#     # 获取当前所有关节角度
#     current_joints = arm.get_current_joint_values()
    
#     # 设置关节6（索引5）为0弧度（打开夹爪）
#     current_joints[5] = 0.0
    
#     # 设置机械臂运动的允许误差值
#     arm.set_goal_joint_tolerance(0.001)
    
#     # 设置允许的最大速度和加速度
#     arm.set_max_acceleration_scaling_factor(0.3)
#     arm.set_max_velocity_scaling_factor(0.3)
    
#     # 设置目标关节角度
#     arm.set_joint_value_target(current_joints)
    
#     # 执行运动
#     arm.go()
#     rospy.sleep(0.5)
#     print("Gripper opened (joint6 = 0.0)")


# def gripper_close():
#     '''
#     函数功能：闭合夹爪（通过设置关节6的角度为0.8）
#     输入参数：无
#     返回值：无
#     '''
#     global arm
    
#     # 获取当前所有关节角度
#     current_joints = arm.get_current_joint_values()
    
#     # 设置关节6（索引5）为0.8弧度（闭合夹爪）
#     current_joints[5] = 0.8
    
#     # 设置机械臂运动的允许误差值
#     arm.set_goal_joint_tolerance(0.001)
    
#     # 设置允许的最大速度和加速度
#     arm.set_max_acceleration_scaling_factor(0.3)
#     arm.set_max_velocity_scaling_factor(0.3)
    
#     # 设置目标关节角度
#     arm.set_joint_value_target(current_joints)
    
#     # 执行运动
#     arm.go()
#     rospy.sleep(0.5)
#     print("Gripper closed (joint6 = 0.8)")


# if __name__ == '__main__':
#     # 初始化move_group的API
#     moveit_commander.roscpp_initialize(sys.argv)
    
#     # 初始化ROS节点
#     rospy.init_node('object_catch', anonymous=True)
    
#     # 初始化需要使用move group控制的机械臂中的arm group
#     arm = moveit_commander.MoveGroupCommander('arm')
    
#     # 初始化打开夹爪
#     gripper_open()
    
#     # 等待接收要抓取的物体信息
#     object_msg = rospy.wait_for_message('/choice_object', String, timeout=None)
    
#     # 订阅物体位姿信息
#     sub_object_pose = rospy.Subscriber("/object_pose", ObjectInfo, object_pose_callback, queue_size=1)
    
#     # 保持节点运行
#     rospy.spin()
    
#     # 关闭并退出moveit
#     moveit_commander.roscpp_shutdown()
#     moveit_commander.os._exit(0)

# #!/usr/bin/env python3
# # -*- coding=UTF-8 -*-
# from std_msgs.msg import String, Bool, Empty
# import rospy, sys
# import moveit_commander
# from geometry_msgs.msg import Pose, PoseStamped
# import numpy as np
# from scipy.spatial.transform import Rotation as R
# from vi_msgs.msg import ObjectInfo
# from geometry_msgs.msg import TransformStamped, PointStamped
# from geometry_msgs.msg import Point, Quaternion

# # 相机坐标系到机械臂末端坐标系的旋转矩阵，通过手眼标定得到
# rotation_matrix = np.array([[1.0, 0.0, 0.0],
#                             [0.0, 0.0, 1.0],
#                             [0.0, -1.0, 0.0]])
# # 相机坐标系到机械臂末端坐标系的平移向量，通过手眼标定得到
# translation_vector = np.array([-0.017, -0.118, 0.0815])

# # 全局变量：MoveIt arm对象
# arm = None
# # TCP偏移量配置(单位:米)
# TCP_OFFSET_X = 0.0
# TCP_OFFSET_Y = 0.09
# TCP_OFFSET_Z = 0.0  # 根据实际夹爪长度调整

# # 相机坐标系物体到机械臂基坐标系转换函数
# def convert(x, y, z, x1, y1, z1, rx, ry, rz):
#     """
#     函数功能：我们需要将旋转向量和平移向量转换为齐次变换矩阵，然后使用深度相机识别到的物体坐标（x, y, z）和
#     机械臂末端的位姿（x1,y1,z1,rx,ry,rz）来计算物体相对于机械臂基座的位姿（x, y, z, rx, ry, rz）
#     输入参数：深度相机识别到的物体坐标（x, y, z）和机械臂末端的位姿（x1,y1,z1,rx,ry,rz）
#     返回值：物体在机械臂基座坐标系下的位置（x, y, z）
#     """
#     global rotation_matrix, translation_vector
#     obj_camera_coordinates = np.array([x, y, z])

#     # 机械臂末端的位姿，单位为弧度
#     end_effector_pose = np.array([x1, y1, z1, rx, ry, rz])
    
#     # 将旋转矩阵和平移向量转换为齐次变换矩阵
#     T_camera_to_end_effector = np.eye(4)
#     T_camera_to_end_effector[:3, :3] = rotation_matrix
#     T_camera_to_end_effector[:3, 3] = translation_vector
    
#     # 机械臂末端的位姿转换为齐次变换矩阵
#     position = end_effector_pose[:3]
#     orientation = R.from_euler('xyz', end_effector_pose[3:], degrees=False).as_matrix()
#     T_base_to_end_effector = np.eye(4)
#     T_base_to_end_effector[:3, :3] = orientation
#     T_base_to_end_effector[:3, 3] = position
    
#     # 计算物体相对于机械臂基座的位姿
#     obj_camera_coordinates_homo = np.append(obj_camera_coordinates, [1])  # 将物体坐标转换为齐次坐标
#     obj_end_effector_coordinates_homo = T_camera_to_end_effector.dot(obj_camera_coordinates_homo)
#     obj_base_coordinates_homo = T_base_to_end_effector.dot(obj_end_effector_coordinates_homo)
#     obj_base_coordinates = obj_base_coordinates_homo[:3]  # 从齐次坐标中提取物体的x, y, z坐标
    
#     # 计算物体的旋转
#     obj_orientation_matrix = T_base_to_end_effector[:3, :3].dot(rotation_matrix)
#     obj_orientation_euler = R.from_matrix(obj_orientation_matrix).as_euler('xyz', degrees=False)
    
#     # 组合结果
#     obj_base_pose = np.hstack((obj_base_coordinates, obj_orientation_euler))
#     obj_base_pose[3:] = rx, ry, rz
#     return obj_base_pose


# def initialize_tcp():
#     """
#     函数功能：初始化并配置TCP(Tool Center Point)
#     输入参数：无
#     返回值：无
#     """
#     global arm, TCP_OFFSET_X, TCP_OFFSET_Y, TCP_OFFSET_Z
    
#     # 方法1: 如果URDF中已经定义了tcp_link,直接设置
#     try:
#         arm.set_end_effector_link("tcp_link")
#         print("=== TCP Configuration ===")
#         print("TCP link set to: tcp_link")
#         print("Current end effector link:", arm.get_end_effector_link())
        
#         # 验证TCP设置
#         tcp_pose = arm.get_current_pose()
#         print("TCP current pose:")
#         print("  Position: x={:.4f}, y={:.4f}, z={:.4f}".format(
#             tcp_pose.pose.position.x,
#             tcp_pose.pose.position.y,
#             tcp_pose.pose.position.z))
#         print("  Orientation: x={:.4f}, y={:.4f}, z={:.4f}, w={:.4f}".format(
#             tcp_pose.pose.orientation.x,
#             tcp_pose.pose.orientation.y,
#             tcp_pose.pose.orientation.z,
#             tcp_pose.pose.orientation.w))
#         print("========================")
        
#     except Exception as e:
#         print("Warning: Could not set tcp_link as end effector")
#         print("Error:", str(e))
#         print("Using default end effector link:", arm.get_end_effector_link())
#         print("TCP offset will be applied in motion planning")
#         print("TCP Offset: x={}, y={}, z={}".format(TCP_OFFSET_X, TCP_OFFSET_Y, TCP_OFFSET_Z))


# def apply_tcp_offset_to_pose(pose, apply_offset=True):
#     """
#     函数功能：为目标位姿应用TCP偏移量
#     输入参数：pose [x, y, z, qx, qy, qz, qw], apply_offset (True=加偏移, False=减偏移)
#     返回值：调整后的pose
#     """
#     global TCP_OFFSET_X, TCP_OFFSET_Y, TCP_OFFSET_Z
    
#     # 如果已经设置了tcp_link,则不需要手动偏移
#     if arm.get_end_effector_link() == "tcp_link":
#         return pose
    
#     adjusted_pose = list(pose)
    
#     # 创建旋转矩阵(从四元数)
#     quat = [pose[3], pose[4], pose[5], pose[6]]  # qx, qy, qz, qw
#     rotation = R.from_quat(quat)
    
#     # 将TCP偏移转换到基坐标系
#     tcp_offset_local = np.array([TCP_OFFSET_X, TCP_OFFSET_Y, TCP_OFFSET_Z])
#     tcp_offset_global = rotation.apply(tcp_offset_local)
    
#     # 应用或移除偏移
#     if apply_offset:
#         # 目标是TCP位置,需要计算法兰位置(减去偏移)
#         adjusted_pose[0] = pose[0] - tcp_offset_global[0]
#         adjusted_pose[1] = pose[1] - tcp_offset_global[1]
#         adjusted_pose[2] = pose[2] - tcp_offset_global[2]
#     else:
#         # 当前是法兰位置,需要计算TCP位置(加上偏移)
#         adjusted_pose[0] = pose[0] + tcp_offset_global[0]
#         adjusted_pose[1] = pose[1] + tcp_offset_global[1]
#         adjusted_pose[2] = pose[2] + tcp_offset_global[2]
    
#     return adjusted_pose


# # 接收到识别物体的回调函数
# def object_pose_callback(data):
#     """
#     函数功能：每帧图像经过识别后的回调函数，若有抓取指令，则判断当前画面帧中是否有被抓物体，如果有则将物体坐标进行转换，并让机械臂执行抓取动作
#     输入参数：无
#     返回值：无
#     """
#     global object_msg, arm
    
#     # 判断当前帧的识别结果是否有要抓取的物体
#     if data.object_class == object_msg.data and len(object_msg.data) > 0:
#         # 使用MoveIt获取当前机械臂末端位姿
#         current_pose = arm.get_current_pose().pose
#         print("Current end effector pose:")
#         print(current_pose)
#         rospy.sleep(1)
        
#         # 使用MoveIt获取当前关节角度
#         current_joints = arm.get_current_joint_values()
#         print("Current joint values:")
#         print(current_joints)
        
#         # 将四元数转换为欧拉角（用于convert函数）
#         quat = [current_pose.orientation.x, current_pose.orientation.y, 
#                 current_pose.orientation.z, current_pose.orientation.w]
#         euler = R.from_quat(quat).as_euler('xyz', degrees=False)
        
#         # 计算机械臂基坐标系下的物体坐标
#         result = convert(data.x, data.y, data.z, 
#                         current_pose.position.x, current_pose.position.y, current_pose.position.z,
#                         euler[0], euler[1], euler[2])
#         print(data.object_class, ':', result)
        
#         # 抓取物体（传递当前位姿和关节角度）
#         # catch(result, current_pose, current_joints)
        
#         # 清除object_msg的信息，之后二次发布抓取物体信息可以再执行
#         object_msg.data = ''


# def movej_type(joint_positions, speed=0.5):
#     '''
#     函数功能：通过输入机械臂每个关节的数值（弧度），让机械臂运动到指定姿态
#     输入参数：joint_positions [joint1,joint2,joint3,joint4,joint5,joint6]、speed (0-1)
#     返回值：无
#     '''
#     global arm
    
#     # 设置机械臂运动的允许误差值
#     arm.set_goal_joint_tolerance(0.001)
    
#     # 设置允许的最大速度和加速度
#     arm.set_max_acceleration_scaling_factor(speed)
#     arm.set_max_velocity_scaling_factor(speed)
    
#     # 设置机械臂的目标位置
#     arm.set_joint_value_target(joint_positions)
    
#     # 控制机械臂完成运动
#     arm.go()
#     rospy.sleep(0.5)


# def movejp_type(pose, speed=0.5):
#     '''
#     函数功能：通过输入机械臂末端的位姿数值，让机械臂运动到指定位姿（关节空间规划）
#     输入参数：pose（position.x、position.y、position.z、orientation.x、orientation.y、orientation.z、orientation.w）、speed
#     返回值：无
#     '''
#     global arm
    
#     # 应用TCP偏移(如果没有设置tcp_link)
#     adjusted_pose = apply_tcp_offset_to_pose(pose, apply_offset=True)
    
#     # 获取终端link的名称
#     end_effector_link = arm.get_end_effector_link()
    
#     # 设置目标位置所使用的参考坐标系
#     reference_frame = 'base_link'
#     arm.set_pose_reference_frame(reference_frame)
    
#     # 当运动规划失败后，允许重新规划
#     arm.allow_replanning(True)
    
#     # 设置位置和姿态的允许误差
#     arm.set_goal_position_tolerance(0.001)
#     arm.set_goal_orientation_tolerance(0.01)
    
#     # 设置允许的最大速度和加速度
#     arm.set_max_acceleration_scaling_factor(speed)
#     arm.set_max_velocity_scaling_factor(speed)
    
#     # 设置机械臂工作空间中的目标位姿
#     target_pose = PoseStamped()
#     target_pose.header.frame_id = reference_frame
#     target_pose.header.stamp = rospy.Time.now()
#     target_pose.pose.position.x = adjusted_pose[0]
#     target_pose.pose.position.y = adjusted_pose[1]
#     target_pose.pose.position.z = adjusted_pose[2]
#     target_pose.pose.orientation.x = adjusted_pose[3]
#     target_pose.pose.orientation.y = adjusted_pose[4]
#     target_pose.pose.orientation.z = adjusted_pose[5]
#     target_pose.pose.orientation.w = adjusted_pose[6]
    
#     # 设置机器臂当前的状态作为运动初始状态
#     arm.set_start_state_to_current_state()
    
#     # 设置机械臂终端运动的目标位姿
#     arm.set_pose_target(target_pose, end_effector_link)
    
#     # 规划并执行运动路径
#     arm.go()
#     rospy.sleep(0.5)


# def movel_type(pose, speed=0.5):
#     '''
#     函数功能：通过输入机械臂末端的位姿数值，让机械臂直线运动到指定位姿（笛卡尔空间规划）
#     输入参数：pose（position.x、position.y、position.z、orientation.x、orientation.y、orientation.z、orientation.w）、speed
#     返回值：无
#     '''
#     global arm
    
#     # 应用TCP偏移(如果没有设置tcp_link)
#     adjusted_pose = apply_tcp_offset_to_pose(pose, apply_offset=True)
    
#     # 获取终端link的名称
#     end_effector_link = arm.get_end_effector_link()
    
#     # 设置目标位置所使用的参考坐标系
#     reference_frame = 'base_link'
#     arm.set_pose_reference_frame(reference_frame)
    
#     # 当运动规划失败后，允许重新规划
#     arm.allow_replanning(True)
    
#     # 设置位置和姿态的允许误差
#     arm.set_goal_position_tolerance(0.001)
#     arm.set_goal_orientation_tolerance(0.01)
    
#     # 设置允许的最大速度和加速度
#     arm.set_max_acceleration_scaling_factor(speed)
#     arm.set_max_velocity_scaling_factor(speed)
    
#     # 设置机械臂工作空间中的目标位姿
#     target_pose = PoseStamped()
#     target_pose.header.frame_id = reference_frame
#     target_pose.header.stamp = rospy.Time.now()
#     target_pose.pose.position.x = adjusted_pose[0]
#     target_pose.pose.position.y = adjusted_pose[1]
#     target_pose.pose.position.z = adjusted_pose[2]
#     target_pose.pose.orientation.x = adjusted_pose[3]
#     target_pose.pose.orientation.y = adjusted_pose[4]
#     target_pose.pose.orientation.z = adjusted_pose[5]
#     target_pose.pose.orientation.w = adjusted_pose[6]
    
#     # 设置机器臂当前的状态作为运动初始状态
#     arm.set_start_state_to_current_state()
    
#     # 设置机械臂终端运动的目标位姿
#     arm.set_pose_target(target_pose, end_effector_link)
    
#     # 规划运动路径
#     traj = arm.plan()
    
#     # 按照规划的运动路径控制机械臂运动
#     arm.execute(traj)
#     rospy.sleep(0.5)


# def arm_ready_pose():
#     '''
#     函数功能：执行整个抓取流程前先运动到一个能够稳定获取物体坐标信息的姿态
#     输入参数：无
#     返回值：无
#     '''
#     global arm
    
#     # 设置机械臂运动的允许误差值
#     arm.set_goal_joint_tolerance(0.001)
    
#     # 设置允许的最大速度和加速度
#     arm.set_max_acceleration_scaling_factor(0.3)
#     arm.set_max_velocity_scaling_factor(0.3)
    
#     # 设置拍照姿态的关节角度
#     pic_joint = [-0.209,-1.326,1.359,0.194,-1.121,0.0]
#     arm.set_joint_value_target(pic_joint)
    
#     # 控制机械臂完成运动
#     arm.go()
#     rospy.sleep(0.5)


# def catch(result, current_pose, current_joints):
#     '''
#     函数功能：机械臂执行抓取动作
#     输入参数：经过convert函数转换得到的'result'、当前末端位姿'current_pose'和当前关节角度'current_joints'
#     返回值：无
#     '''
#     # 流程第一步：运动到物体附近（偏移7cm）
#     arm_ready_pose()
#     movejp_type([result[0], result[1], result[2]+0.07, 
#                  current_pose.orientation.x, current_pose.orientation.y,
#                  current_pose.orientation.z, current_pose.orientation.w], 0.3)
#     print('*************************catching  step1*************************')

#     # 抓取第二步：直线运动到物体坐标处
#     movel_type([result[0], result[1], result[2], 
#                 current_pose.orientation.x, current_pose.orientation.y,
#                 current_pose.orientation.z, current_pose.orientation.w], 0.3)
#     print('*************************catching  step2*************************')

#     # 抓取第三步：闭合夹爪
#     gripper_close()
#     print('*************************catching  step3*************************')

#     # 倒水第一步：抬起物体5厘米
#     movel_type([result[0], result[1], result[2] + 0.05, 
#                 current_pose.orientation.x, current_pose.orientation.y,
#                 current_pose.orientation.z, current_pose.orientation.w], 0.3)
#     print('*************************pour  step1*************************')

#     # 倒水第二步：旋转机械臂末端关节
#     movej_type([current_joints[0], current_joints[1], current_joints[2], 
#                 current_joints[3], current_joints[4], current_joints[5]], 0.3)
#     print('*************************pour  step2*************************')


# def gripper_open():
#     '''
#     函数功能：打开夹爪（通过设置关节6的角度为0）
#     输入参数：无
#     返回值：无
#     '''
#     global arm
    
#     # 获取当前所有关节角度
#     current_joints = arm.get_current_joint_values()
    
#     # 设置关节6（索引5）为0弧度（打开夹爪）
#     current_joints[5] = 0.0
    
#     # 设置机械臂运动的允许误差值
#     arm.set_goal_joint_tolerance(0.001)
    
#     # 设置允许的最大速度和加速度
#     arm.set_max_acceleration_scaling_factor(0.3)
#     arm.set_max_velocity_scaling_factor(0.3)
    
#     # 设置目标关节角度
#     arm.set_joint_value_target(current_joints)
    
#     # 执行运动
#     arm.go()
#     rospy.sleep(0.5)
#     print("Gripper opened (joint6 = 0.0)")


# def gripper_close():
#     '''
#     函数功能：闭合夹爪（通过设置关节6的角度为0.8）
#     输入参数：无
#     返回值：无
#     '''
#     global arm
    
#     # 获取当前所有关节角度
#     current_joints = arm.get_current_joint_values()
    
#     # 设置关节6（索引5）为0.8弧度（闭合夹爪）
#     current_joints[5] = 0.8
    
#     # 设置机械臂运动的允许误差值
#     arm.set_goal_joint_tolerance(0.001)
    
#     # 设置允许的最大速度和加速度
#     arm.set_max_acceleration_scaling_factor(0.3)
#     arm.set_max_velocity_scaling_factor(0.3)
    
#     # 设置目标关节角度
#     arm.set_joint_value_target(current_joints)
    
#     # 执行运动
#     arm.go()
#     rospy.sleep(0.5)
#     print("Gripper closed (joint6 = 0.8)")


# if __name__ == '__main__':
#     # 初始化move_group的API
#     moveit_commander.roscpp_initialize(sys.argv)
    
#     # 初始化ROS节点
#     rospy.init_node('object_catch', anonymous=True)
    
#     # 初始化需要使用move group控制的机械臂中的arm group
#     arm = moveit_commander.MoveGroupCommander('arm')
    
#     # ========== 初始化TCP配置 ==========
#     initialize_tcp()
#     # ===================================
    
#     # 初始化打开夹爪
#     gripper_open()
    
#     # 等待接收要抓取的物体信息
#     object_msg = rospy.wait_for_message('/choice_object', String, timeout=None)
    
#     # 订阅物体位姿信息
#     sub_object_pose = rospy.Subscriber("/object_pose", ObjectInfo, object_pose_callback, queue_size=1)
    
#     # 保持节点运行
#     rospy.spin()
    
#     # 关闭并退出moveit
#     moveit_commander.roscpp_shutdown()
#     moveit_commander.os._exit(0)



#!/usr/bin/env python3
# -*- coding=UTF-8 -*-
from std_msgs.msg import String, Bool, Empty
import rospy, sys
import moveit_commander
# from rm_msgs.msg import MoveJ_P, Arm_Current_State, Gripper_Set, Gripper_Pick, ArmState, MoveL, MoveJ
from geometry_msgs.msg import Pose, PoseStamped
import numpy as np
from scipy.spatial.transform import Rotation as R
from vi_msgs.msg import ObjectInfo
from geometry_msgs.msg import TransformStamped, PointStamped
from geometry_msgs.msg import Point, Quaternion
import math

# 相机坐标系到机械臂末端坐标系的旋转矩阵，通过手眼标定得到
rotation_matrix = np.array([[1.0, 0.0, 0.0],
                            [0.0, 0.0, 1.0],
                            [0.0, -1.0, 0.0]])
# 相机坐标系到机械臂末端坐标系的平移向量，通过手眼标定得到
translation_vector = np.array([-0.017, -0.028, 0.0815])

# 全局变量：MoveIt arm对象
arm = None

# 相机坐标系物体到机械臂基坐标系转换函数
def convert(x, y, z, x1, y1, z1, rx, ry, rz):
    """
    函数功能：我们需要将旋转向量和平移向量转换为齐次变换矩阵，然后使用深度相机识别到的物体坐标（x, y, z）和
    机械臂末端的位姿（x1,y1,z1,rx,ry,rz）来计算物体相对于机械臂基座的位姿（x, y, z, rx, ry, rz）
    输入参数：深度相机识别到的物体坐标（x, y, z）和机械臂末端的位姿（x1,y1,z1,rx,ry,rz）
    返回值：物体在机械臂基座坐标系下的位置（x, y, z）
    """
    global rotation_matrix, translation_vector
    obj_camera_coordinates = np.array([x, y, z])

    # 机械臂末端的位姿，单位为弧度
    end_effector_pose = np.array([x1, y1, z1, rx, ry, rz])
    
    # 将旋转矩阵和平移向量转换为齐次变换矩阵
    T_camera_to_end_effector = np.eye(4)
    T_camera_to_end_effector[:3, :3] = rotation_matrix
    T_camera_to_end_effector[:3, 3] = translation_vector
    
    # 机械臂末端的位姿转换为齐次变换矩阵
    position = end_effector_pose[:3]
    orientation = R.from_euler('xyz', end_effector_pose[3:], degrees=False).as_matrix()
    T_base_to_end_effector = np.eye(4)
    T_base_to_end_effector[:3, :3] = orientation
    T_base_to_end_effector[:3, 3] = position
    
    # 计算物体相对于机械臂基座的位姿
    obj_camera_coordinates_homo = np.append(obj_camera_coordinates, [1])  # 将物体坐标转换为齐次坐标
    obj_end_effector_coordinates_homo = T_camera_to_end_effector.dot(obj_camera_coordinates_homo)
    obj_base_coordinates_homo = T_base_to_end_effector.dot(obj_end_effector_coordinates_homo)
    obj_base_coordinates = obj_base_coordinates_homo[:3]  # 从齐次坐标中提取物体的x, y, z坐标
    
    # 计算物体的旋转
    obj_orientation_matrix = T_base_to_end_effector[:3, :3].dot(rotation_matrix)
    obj_orientation_euler = R.from_matrix(obj_orientation_matrix).as_euler('xyz', degrees=False)
    
    # 组合结果
    obj_base_pose = np.hstack((obj_base_coordinates, obj_orientation_euler))
    obj_base_pose[3:] = rx, ry, rz
    return obj_base_pose


# 接收到识别物体的回调函数
def object_pose_callback(data):
    """
    函数功能：每帧图像经过识别后的回调函数，若有抓取指令，则判断当前画面帧中是否有被抓物体，如果有则将物体坐标进行转换，并让机械臂执行抓取动作
    输入参数：无
    返回值：无
    """
    global object_msg, arm
    
    # 判断当前帧的识别结果是否有要抓取的物体
    if data.object_class == object_msg.data and len(object_msg.data) > 0:
        # 使用MoveIt获取当前机械臂末端位姿
        current_pose = arm.get_current_pose().pose
        print("Current end effector pose:")
        print(current_pose)
        rospy.sleep(1)
        
        # 使用MoveIt获取当前关节角度
        current_joints = arm.get_current_joint_values()
        print("Current joint values:")
        print(current_joints)
        
        # 将四元数转换为欧拉角（用于convert函数）
        quat = [current_pose.orientation.x, current_pose.orientation.y, 
                current_pose.orientation.z, current_pose.orientation.w]
        euler = R.from_quat(quat).as_euler('xyz', degrees=False)
        
        # 计算机械臂基坐标系下的物体坐标
        result = convert(data.x, data.y, data.z, 
                        current_pose.position.x, current_pose.position.y, current_pose.position.z,
                        euler[0], euler[1], euler[2])
        print(data.object_class, ':', result)
        
        # 抓取物体（传递当前位姿和关节角度）
        catch(result, current_pose, current_joints)
        
        # 清除object_msg的信息，之后二次发布抓取物体信息可以再执行
        object_msg.data = ''


def movej_type(joint_positions, speed=0.5):
    '''
    函数功能：通过输入机械臂每个关节的数值（弧度），让机械臂运动到指定姿态
    输入参数：joint_positions [joint1,joint2,joint3,joint4,joint5,joint6]、speed (0-1)
    返回值：无
    '''
    global arm
    
    # 设置机械臂运动的允许误差值
    arm.set_goal_joint_tolerance(0.001)
    
    # 设置允许的最大速度和加速度
    arm.set_max_acceleration_scaling_factor(speed)
    arm.set_max_velocity_scaling_factor(speed)
    
    # 设置机械臂的目标位置
    arm.set_joint_value_target(joint_positions)
    
    # 控制机械臂完成运动
    arm.go()
    rospy.sleep(0.5)


def movejp_type(pose, speed=0.5):
    '''
    函数功能：通过输入机械臂末端的位姿数值，让机械臂运动到指定位姿（关节空间规划）
    输入参数：pose（position.x、position.y、position.z、orientation.x、orientation.y、orientation.z、orientation.w）、speed
    返回值：无
    '''
    global arm
    
    # 获取终端link的名称
    end_effector_link = arm.get_end_effector_link()
    
    # 设置目标位置所使用的参考坐标系
    reference_frame = 'base_link'
    arm.set_pose_reference_frame(reference_frame)
    
    # 当运动规划失败后，允许重新规划
    arm.allow_replanning(True)
    
    # 设置位置和姿态的允许误差
    arm.set_goal_position_tolerance(0.001)
    arm.set_goal_orientation_tolerance(0.01)
    
    # 设置允许的最大速度和加速度
    arm.set_max_acceleration_scaling_factor(speed)
    arm.set_max_velocity_scaling_factor(speed)
        
    # pose = [
    # 9.747675042543619e-06,
    # 0.129637194657656,
    # 0.34817380552805055,
    # -0.6113449555026431,
    # -0.0003924356916525224,
    # 0.0003881465371548759,
    # 0.7913640380494712
    # ]
    # 设置机械臂工作空间中的目标位姿
    target_pose = PoseStamped()
    print(type(target_pose))
    target_pose.header.frame_id = reference_frame
    target_pose.header.stamp = rospy.Time.now()
    target_pose.pose.position.x = pose[0]
    target_pose.pose.position.y = pose[1]
    target_pose.pose.position.z = pose[2]
    target_pose.pose.orientation.x = pose[3]
    target_pose.pose.orientation.y = pose[4]
    target_pose.pose.orientation.z = pose[5]
    target_pose.pose.orientation.w = pose[6]
    print(target_pose)
    
    # 设置机器臂当前的状态作为运动初始状态
    arm.set_start_state_to_current_state()

    # 设置机械臂终端运动的目标位姿
    arm.set_pose_target(target_pose, end_effector_link)
    print("joint=====================",arm.get_joint_value_target())
    # arm.compute_ik()
    
    # # 规划并执行运动路径
    # print(1)
    # arm.go()
    # print(2)
    # rospy.sleep(0.5)

    # joint_positions = arm.get_joint_value_target()
    # arm.set_joint_value_target(joint_positions)  #设置关节值作为目标值
                
    # # 控制机械臂完成运动
    # arm.go()   # 规划+执行
    # rospy.sleep(1)




def movel_type(pose, speed=0.5):
    '''
    函数功能：通过输入机械臂末端的位姿数值，让机械臂直线运动到指定位姿（笛卡尔空间规划）
    输入参数：pose（position.x、position.y、position.z、orientation.x、orientation.y、orientation.z、orientation.w）、speed
    返回值：无
    '''
    global arm
    
    # 获取终端link的名称
    end_effector_link = arm.get_end_effector_link()
    
    # 设置目标位置所使用的参考坐标系
    reference_frame = 'base_link'
    arm.set_pose_reference_frame(reference_frame)
    
    # 当运动规划失败后，允许重新规划
    arm.allow_replanning(True)
    
    # 设置位置和姿态的允许误差
    arm.set_goal_position_tolerance(0.001)
    arm.set_goal_orientation_tolerance(0.01)
    
    # 设置允许的最大速度和加速度
    arm.set_max_acceleration_scaling_factor(speed)
    arm.set_max_velocity_scaling_factor(speed)
    
    # 设置机械臂工作空间中的目标位姿
    target_pose = PoseStamped()
    print(type(target_pose))
    print(target_pose)
    target_pose.header.frame_id = reference_frame
    target_pose.header.stamp = rospy.Time.now()
    target_pose.pose.position.x = pose[0]
    target_pose.pose.position.y = pose[1]
    target_pose.pose.position.z = pose[2]
    target_pose.pose.orientation.x = pose[3]
    target_pose.pose.orientation.y = pose[4]
    target_pose.pose.orientation.z = pose[5]
    target_pose.pose.orientation.w = pose[6]
    
    # 设置机器臂当前的状态作为运动初始状态
    arm.set_start_state_to_current_state()
    
    # 设置机械臂终端运动的目标位姿
    arm.set_pose_target(target_pose, end_effector_link)

    # 规划运动路径
    traj = arm.plan()
    
    # 按照规划的运动路径控制机械臂运动
    arm.execute(traj)
    rospy.sleep(0.5)


def arm_ready_pose():
    '''
    函数功能：执行整个抓取流程前先运动到一个能够稳定获取物体坐标信息的姿态
    输入参数：无
    返回值：无
    '''
    global arm
    
    # 设置机械臂运动的允许误差值
    arm.set_goal_joint_tolerance(0.001)
    
    # 设置允许的最大速度和加速度
    arm.set_max_acceleration_scaling_factor(0.3)
    arm.set_max_velocity_scaling_factor(0.3)
    
    # 设置拍照姿态的关节角度
    pic_joint = [-0.209,-1.326,1.359,0.194,-1.121,0.0]
    arm.set_joint_value_target(pic_joint)
    
    # 控制机械臂完成运动
    arm.go()
    rospy.sleep(0.5)


def catch(result, current_pose, current_joints):
    '''
    函数功能：机械臂执行抓取动作
    输入参数：经过convert函数转换得到的'result'、当前末端位姿'current_pose'和当前关节角度'current_joints'
    返回值：无
    '''
    # 流程第一步：运动到物体附近（偏移7cm）

    yaw = math.atan2(result[1], result[0])
    target_orientation = R.from_euler('xyz', [-20, 0, yaw], degrees=True).as_quat()
    target_position = [result[0], result[1], result[2]]
    distance_in_xy = math.sqrt(target_position[0]**2 + target_position[1]**2)
    target_position = [result[0]*(1-0.1/distance_in_xy), result[1]*(1-0.1/distance_in_xy), result[2]+0.08]
    movejp_type([target_position[0], target_position[1], target_position[2],
                 target_orientation[0], target_orientation[1], 
                 target_orientation[2], target_orientation[3]], 0.3)
    print("moving to pose:", target_position, R.from_quat(target_orientation).as_euler('xyz', degrees=True))

    # movejp_type([result[0], result[1], result[2]+0.1, 
    #             current_pose.orientation.x, current_pose.orientation.y,
    #             current_pose.orientation.z, current_pose.orientation.w], 0.3)

    # # 流程第一步：运动到物体附近（偏移7cm）
    # movejp_type([result[0], result[1], result[2] + 0.2, 
    #              current_pose.orientation.x, current_pose.orientation.y,
    #              current_pose.orientation.z, current_pose.orientation.w], 0.3)
    # print("moving to pose:", [result[0], result[1], result[2]+0.2], [current_pose.orientation.x, current_pose.orientation.y,
    #             current_pose.orientation.z, current_pose.orientation.w])
    print('*************************catching  step1*************************')

    # # 抓取第二步：直线运动到物体坐标处
    # movel_type([result[0], result[1], result[2], 
    #             current_pose.orientation.x, current_pose.orientation.y,
    #             current_pose.orientation.z, current_pose.orientation.w], 0.3)
    # print('*************************catching  step2*************************')

    # # 抓取第三步：闭合夹爪
    # gripper_close()
    # print('*************************catching  step3*************************')

    # # 倒水第一步：抬起物体5厘米
    # movel_type([result[0], result[1], result[2] + 0.05, 
    #             current_pose.orientation.x, current_pose.orientation.y,
    #             current_pose.orientation.z, current_pose.orientation.w], 0.3)
    # print('*************************pour  step1*************************')

    # # 倒水第二步：旋转机械臂末端关节
    # movej_type([current_joints[0], current_joints[1], current_joints[2], 
    #             current_joints[3], current_joints[4], current_joints[5] + 1], 0.3)
    # print('*************************pour  step2*************************')


def gripper_open():
    '''
    函数功能：打开夹爪（通过设置关节6的角度为0）
    输入参数：无
    返回值：无
    '''
    global arm
    
    # 获取当前所有关节角度
    current_joints = arm.get_current_joint_values()
    
    # 设置关节6（索引5）为0弧度（打开夹爪）
    current_joints[5] = 0.0
    
    # 设置机械臂运动的允许误差值
    arm.set_goal_joint_tolerance(0.001)
    
    # 设置允许的最大速度和加速度
    arm.set_max_acceleration_scaling_factor(0.3)
    arm.set_max_velocity_scaling_factor(0.3)
    
    # 设置目标关节角度
    arm.set_joint_value_target(current_joints)
    
    # 执行运动
    arm.go()
    rospy.sleep(0.5)
    print("Gripper opened (joint6 = 0.0)")


def gripper_close():
    '''
    函数功能：闭合夹爪（通过设置关节6的角度为0.8）
    输入参数：无
    返回值：无
    '''
    global arm
    
    # 获取当前所有关节角度
    current_joints = arm.get_current_joint_values()
    
    # 设置关节6（索引5）为0.8弧度（闭合夹爪）
    current_joints[5] = 0.8
    
    # 设置机械臂运动的允许误差值
    arm.set_goal_joint_tolerance(0.001)
    
    # 设置允许的最大速度和加速度
    arm.set_max_acceleration_scaling_factor(0.3)
    arm.set_max_velocity_scaling_factor(0.3)
    
    # 设置目标关节角度
    arm.set_joint_value_target(current_joints)
    
    # 执行运动
    arm.go()
    rospy.sleep(0.5)
    print("Gripper closed (joint6 = 0.8)")


if __name__ == '__main__':
    # 初始化move_group的API
    moveit_commander.roscpp_initialize(sys.argv)
    
    # 初始化ROS节点
    rospy.init_node('object_catch', anonymous=True)
    
    # 初始化需要使用move group控制的机械臂中的arm group
    arm = moveit_commander.MoveGroupCommander('arm')

    arm.set_goal_position_tolerance(0.01)          # 2025/12/13 lk
    arm.set_goal_orientation_tolerance(0.1)
    
    # 初始化打开夹爪
    gripper_open()
    
    # 等待接收要抓取的物体信息
    object_msg = rospy.wait_for_message('/choice_object', String, timeout=None)
    
    # 订阅物体位姿信息
    sub_object_pose = rospy.Subscriber("/object_pose", ObjectInfo, object_pose_callback, queue_size=1)
    
    # 保持节点运行
    rospy.spin()
    
    # 关闭并退出moveit
    moveit_commander.roscpp_shutdown()
    moveit_commander.os._exit(0)